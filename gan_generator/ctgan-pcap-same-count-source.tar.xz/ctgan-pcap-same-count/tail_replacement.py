"""Exact-file-size, trailing-packet replacement for classic PCAP and PCAPNG.

The original container is patched in-place (on a copy). Packet records, block
sizes, captured packet lengths, timestamps and all nonpacket metadata are kept
byte-for-byte. Synthetic packet contents use CTGAN-sampled flow features but
are templated from the original L2/L3/L4 layout; NOT application-valid traffic.
"""
from __future__ import annotations

import hashlib
import math
import random
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


class CaptureError(ValueError):
    pass


@dataclass(frozen=True)
class PacketSlot:
    index: int
    offset: int
    length: int
    linktype: int


def _read_u32(raw: bytes, pos: int, endian: str) -> int:
    return struct.unpack_from(endian + 'I', raw, pos)[0]


def _validate_block(data: bytes, pos: int, length: int, endian: str) -> None:
    if length < 12 or length % 4 or pos + length > len(data):
        raise CaptureError(f'Invalid PCAPNG block at {pos} (size {length})')
    if _read_u32(data, pos + length - 4, endian) != length:
        raise CaptureError(f'PCAPNG block end-length mismatch at {pos}')


def _reject_packet_hash_options(data: bytes, start: int, stop: int, endian: str):
    """PCAPNG packet hash option would become stale after altering packet bytes."""
    p = start
    while p + 4 <= stop:
        code, size = struct.unpack_from(endian + 'HH', data, p)
        if code == 0:
            return
        if code == 3:
            raise CaptureError('PCAPNG packet-hash option found; strict mode refuses stale packet hashes')
        p += 4 + ((size + 3) & ~3)
        if p > stop:
            raise CaptureError('Malformed PCAPNG packet options')


def locate_packet_slots(data: bytes) -> list[PacketSlot]:
    """Locate record payload offsets without rewriting capture container blocks."""
    if len(data) < 24:
        raise CaptureError('Capture is too short')
    pcap_magic = {b'\xd4\xc3\xb2\xa1': '<', b'\xa1\xb2\xc3\xd4': '>',
                  b'\x4d\x3c\xb2\xa1': '<', b'\xa1\xb2\x3c\x4d': '>'}
    if data[:4] in pcap_magic:
        endian = pcap_magic[data[:4]]
        linktype = _read_u32(data, 20, endian) & 0xffff
        p = 24
        slots = []
        while p < len(data):
            if p + 16 > len(data):
                raise CaptureError(f'Truncated PCAP packet header at {p}')
            caplen = _read_u32(data, p + 8, endian)
            if caplen == 0 or p + 16 + caplen > len(data):
                raise CaptureError(f'Invalid PCAP packet length at {p}: {caplen}')
            slots.append(PacketSlot(len(slots), p + 16, caplen, linktype))
            p += 16 + caplen
        return slots
    if data[:4] != b'\x0a\x0d\x0d\x0a':
        raise CaptureError('Unrecognized PCAP/PCAPNG header')
    p = 0
    endian = None
    interfaces = []
    slots = []
    while p < len(data):
        if p + 12 > len(data):
            raise CaptureError('Truncated PCAPNG block header')
        if data[p:p+4] == b'\x0a\x0d\x0d\x0a':
            bom = data[p + 8:p + 12]
            if bom == b'\x4d\x3c\x2b\x1a':
                endian = '<'
            elif bom == b'\x1a\x2b\x3c\x4d':
                endian = '>'
            else:
                raise CaptureError('Bad PCAPNG section byte-order magic')
            interfaces = []
        if endian is None:
            raise CaptureError('Missing PCAPNG section header')
        typ = _read_u32(data, p, endian)
        length = _read_u32(data, p + 4, endian)
        _validate_block(data, p, length, endian)
        if typ == 1:  # IDB
            if length < 20:
                raise CaptureError('Truncated PCAPNG interface description')
            interfaces.append(struct.unpack_from(endian + 'H', data, p + 8)[0])
        elif typ == 6:  # Enhanced Packet Block
            if length < 32:
                raise CaptureError('Truncated PCAPNG enhanced packet')
            interface_id = _read_u32(data, p + 8, endian)
            caplen = _read_u32(data, p + 20, endian)
            origlen = _read_u32(data, p + 24, endian)
            packet_start = p + 28
            options_start = packet_start + ((caplen + 3) & ~3)
            if interface_id >= len(interfaces) or caplen == 0 or origlen < caplen or options_start > p + length - 4:
                raise CaptureError('Bad PCAPNG enhanced-packet fields')
            _reject_packet_hash_options(data, options_start, p + length - 4, endian)
            slots.append(PacketSlot(len(slots), packet_start, caplen, interfaces[interface_id]))
        elif typ == 2:  # Obsolete Packet Block, supported to avoid miscounting
            if length < 32:
                raise CaptureError('Truncated PCAPNG packet block')
            interface_id = struct.unpack_from(endian + 'H', data, p + 8)[0]
            caplen = _read_u32(data, p + 20, endian)
            origlen = _read_u32(data, p + 24, endian)
            options_start = p + 28 + ((caplen + 3) & ~3)
            if interface_id >= len(interfaces) or caplen == 0 or origlen < caplen or options_start > p + length - 4:
                raise CaptureError('Bad PCAPNG packet-block fields')
            _reject_packet_hash_options(data, options_start, p + length - 4, endian)
            slots.append(PacketSlot(len(slots), p + 28, caplen, interfaces[interface_id]))
        elif typ == 3:
            raise CaptureError('PCAPNG Simple Packet Blocks are not supported in exact-size mode')
        p += length
    return slots


def suffix_start(slots: list[PacketSlot], pct: int, basis: str = 'packets') -> int:
    if not 0 <= pct <= 100:
        raise ValueError(f'Percentage must be 0..100, got {pct}')
    if basis not in {'packets', 'packet-bytes'}:
        raise ValueError('basis must be packets or packet-bytes')
    if pct == 0:
        return len(slots)
    if pct == 100:
        return 0
    if basis == 'packets':
        n = max(1, math.floor(len(slots) * pct / 100 + .5))
        return len(slots) - n
    target = sum(s.length for s in slots) * pct / 100
    accum = 0
    start = len(slots)
    for i in range(len(slots) - 1, -1, -1):
        nxt = accum + slots[i].length
        if abs(nxt - target) <= abs(accum - target):
            accum, start = nxt, i
        else:
            break
    return min(start, len(slots) - 1)  # nonzero targets always replace at least one slot


def checksum(buf: bytes) -> int:
    if len(buf) % 2:
        buf += b'\x00'
    v = sum(struct.unpack('!' + 'H' * (len(buf)//2), buf))
    while v >> 16:
        v = (v & 0xffff) + (v >> 16)
    return (~v) & 0xffff


def ipv4_offset(packet: bytes, linktype: int) -> int:
    if linktype == 101:  # LINKTYPE_RAW
        return 0
    if linktype == 1:  # Ethernet + optional stacked VLANs
        if len(packet) < 14:
            raise CaptureError('Truncated Ethernet header')
        ethertype = struct.unpack_from('!H', packet, 12)[0]
        offset = 14
        for _ in range(8):
            if ethertype not in {0x8100, 0x88a8, 0x9100}:
                break
            if len(packet) < offset + 4:
                raise CaptureError('Truncated VLAN header')
            ethertype = struct.unpack_from('!H', packet, offset + 2)[0]
            offset += 4
        if ethertype != 0x0800:
            raise CaptureError(f'Unsupported Ethernet payload 0x{ethertype:04x}')
        return offset
    if linktype == 113:  # Linux cooked capture v1
        if len(packet) < 16 or struct.unpack_from('!H', packet, 14)[0] != 0x0800:
            raise CaptureError('Unsupported or truncated SLL packet')
        return 16
    if linktype == 276:  # Linux cooked capture v2
        if len(packet) < 20 or struct.unpack_from('!H', packet, 0)[0] != 0x0800:
            raise CaptureError('Unsupported or truncated SLL2 packet')
        return 20
    raise CaptureError(f'Unsupported linktype {linktype}; only Ethernet, RAW, SLL, SLL2 are supported')


def _bounded(value, low: int, high: int, default: int) -> int:
    try:
        n = float(value)
        return max(low, min(high, round(n))) if math.isfinite(n) else default
    except (TypeError, ValueError, OverflowError):
        return default


def synthesize_fixed_length(original: bytes, linktype: int, feature: Mapping, seed: int,
                            original_service: int | None = None) -> bytes:
    """Generate a changed, valid IPv4 TCP/UDP datagram of IDENTICAL byte length.

    Generates random opaque payload and GAN-conditioned TTL / service port.
    Preserves captured IPv4 header layout, endpoints, TCP/UDP flags and packet
    size; checksums recalculated. Not a semantic/application-layer generator.
    """
    rng = random.Random(seed)
    packet = bytearray(original)
    base = ipv4_offset(packet, linktype)
    if base + 20 > len(packet) or packet[base] >> 4 != 4:
        raise CaptureError('Expected IPv4 header')
    hlen = (packet[base] & 0x0f) * 4
    total = struct.unpack_from('!H', packet, base + 2)[0]
    if hlen < 20 or total < hlen or base + total > len(packet):
        raise CaptureError('Truncated or invalid IPv4 datagram; cannot rebuild checksums')
    frag = struct.unpack_from('!H', packet, base + 6)[0]
    if frag & 0x3fff:
        raise CaptureError('IPv4 fragments are not supported for exact-size regeneration')
    protocol = packet[base + 9]
    l4 = base + hlen
    if protocol == 6:
        if l4 + 20 > base + total:
            raise CaptureError('Truncated TCP header')
        l4_hlen = (packet[l4 + 12] >> 4) * 4
        if l4_hlen < 20 or l4 + l4_hlen > base + total:
            raise CaptureError('Invalid TCP header length')
    elif protocol == 17:
        if l4 + 8 > base + total:
            raise CaptureError('Truncated UDP header')
        l4_hlen = 8
        udp_len = struct.unpack_from('!H', packet, l4 + 4)[0]
        if udp_len < 8 or udp_len != total - hlen:
            raise CaptureError('UDP length differs from IPv4 payload length')
    else:
        raise CaptureError(f'Unsupported IPv4 protocol {protocol}; require TCP or UDP')
    desired_proto = str(feature.get('protocol', ''))
    if desired_proto and desired_proto not in {'TCP' if protocol == 6 else 'UDP'}:
        # Do not switch protocols because this would change header size.
        # Caller records this fixed-size, template-conditioned limitation.
        pass

    old_ip_id = struct.unpack_from('!H', packet, base + 4)[0]
    struct.pack_into('!H', packet, base + 4, (old_ip_id + 1 + rng.randrange(65535)) & 0xffff)
    packet[base + 8] = _bounded(feature.get('mean_ttl'), 1, 255, 64)

    # Match the generated service port to either direction of the existing flow.
    try:
        new_service = int(str(feature.get('service_port', 'other')))
    except (ValueError, TypeError):
        new_service = None
    if new_service is not None and 1 <= new_service <= 65535 and original_service is not None:
        old_src, old_dst = struct.unpack_from('!HH', packet, l4)
        if old_dst == original_service:
            struct.pack_into('!H', packet, l4 + 2, new_service)
        elif old_src == original_service:
            struct.pack_into('!H', packet, l4, new_service)

    payload_start = l4 + l4_hlen
    payload_len = base + total - payload_start
    if payload_len:
        packet[payload_start:base+total] = rng.randbytes(payload_len)
    # Keep original flags, seq/ack, TCP options and packet lengths. Payload is
    # synthetic, but application framing and TCP continuity are NOT assured.
    packet[base + 10:base + 12] = b'\x00\x00'
    struct.pack_into('!H', packet, base + 10, checksum(packet[base:base+hlen]))
    csum_off = l4 + (16 if protocol == 6 else 6)
    packet[csum_off:csum_off+2] = b'\x00\x00'
    segment = packet[l4:base+total]
    pseudo = packet[base+12:base+20] + struct.pack('!BBH', 0, protocol, len(segment))
    computed = checksum(pseudo + segment)
    if protocol == 17 and computed == 0:
        computed = 0xffff
    struct.pack_into('!H', packet, csum_off, computed)
    if len(packet) != len(original) or packet == original:
        raise AssertionError('Synthetic packet must be changed without changing length')
    return bytes(packet)


def patched_capture(original: bytes, slots: list[PacketSlot], start: int,
                    features_by_slot: Mapping[int, Mapping], services_by_slot: Mapping[int, int],
                    seed: int) -> tuple[bytes, int]:
    result = bytearray(original)
    count = 0
    for slot in slots[start:]:
        raw = original[slot.offset:slot.offset+slot.length]
        new = synthesize_fixed_length(raw, slot.linktype, features_by_slot[slot.index],
                                      seed * 1000003 + slot.index, services_by_slot.get(slot.index))
        result[slot.offset:slot.offset+slot.length] = new
        count += 1
    if len(result) != len(original):
        raise AssertionError('File size changed')
    return bytes(result), count


def verify_exact_size(original: bytes, result: bytes, slots: list[PacketSlot], start: int) -> None:
    if len(result) != len(original):
        raise AssertionError('Output file does not match original size')
    rescanned = locate_packet_slots(result)
    if rescanned != slots:
        raise AssertionError('Packet slot or capture metadata changed')
    for slot in slots:
        before = original[slot.offset:slot.offset+slot.length]
        after = result[slot.offset:slot.offset+slot.length]
        if (slot.index >= start) == (before == after):
            raise AssertionError(f'Unexpected packet difference at packet {slot.index}')
    # Check every non-payload span rather than allocating a second file-sized
    # byte mask. Includes timestamps, capture headers and PCAPNG options/padding.
    previous = 0
    for slot in slots:
        if original[previous:slot.offset] != result[previous:slot.offset]:
            raise AssertionError('Capture metadata changed outside packet bytes')
        previous = slot.offset + slot.length
    if original[previous:] != result[previous:]:
        raise AssertionError('Trailing capture metadata changed')


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

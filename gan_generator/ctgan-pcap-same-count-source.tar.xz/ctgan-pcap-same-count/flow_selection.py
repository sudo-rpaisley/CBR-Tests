"""Reproducible nested whole-flow selection, without PCAP/GAN dependencies."""
import bisect
import random


def select_nested(flow_packet_counts, total_packets, percentages, seed=42, trials=128):
    """Return {pct: frozenset(flow_ids)} using nested random order.

    Choose the best of several deterministic permutations to reduce the *total*
    packet-count deviation across percentage steps, without dividing flows.
    """
    if any(n <= 0 for n in flow_packet_counts.values()):
        raise ValueError("Flow packet counts must be positive")
    supported = sum(flow_packet_counts.values())
    if not 0 <= supported <= total_packets:
        raise ValueError("Invalid flow packet counts")
    percentages = sorted(set(percentages))
    if not percentages or any(p < 0 or p > 100 for p in percentages):
        raise ValueError("Percentages must be nonempty and in [0, 100]")
    if trials < 1:
        raise ValueError("trials must be positive")
    rng = random.Random(seed)
    original_ids = sorted(flow_packet_counts)
    targets = [(pct, round(total_packets * pct / 100)) for pct in percentages]
    best_score, best_ids, best_ks = None, None, None
    for _ in range(trials):
        ids = original_ids.copy()
        rng.shuffle(ids)
        cumul = [0]
        for fid in ids:
            cumul.append(cumul[-1] + flow_packet_counts[fid])
        ks = {}
        score = 0
        for pct, target in targets:
            if pct == 0:
                k = 0
            elif pct == 100:
                k = len(ids)
            else:
                upper = bisect.bisect_left(cumul, target)
                options = [min(len(ids), upper), max(0, upper - 1)]
                k = min(options, key=lambda i: (abs(cumul[i] - target), i))
            ks[pct] = k
            score += abs(cumul[k] - target)
        if best_score is None or score < best_score:
            best_score, best_ids, best_ks = score, ids, ks
            if score == 0:
                break
    return {pct: frozenset(best_ids[:best_ks[pct]]) for pct in percentages}

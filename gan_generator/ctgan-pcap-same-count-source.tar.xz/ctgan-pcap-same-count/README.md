# CTGAN network traffic perturbation: trailing suffix, same packet count

## Experimental specification

This project generates a deterministic 0%, 10%, 20%, ... 100% sweep from an **original PCAP or PCAPNG**, using a **CTGAN trained on separate network-flow features**.

- **Same packet count** as the original in *every* output.
- **Final X% of packets are replaced**, not selected randomly throughout the file. 10% means the last 10% of packet positions; 20% means the last 20%, etc.
- **The first 100-X% of captured packet records are unchanged**. Original capture timestamps, metadata, and interface definitions are retained.
- **The replacement packets can differ in size**, unlike the previous strict-size version. The byte total of *each newly replaced band* is balanced to the corresponding source band's byte total, within valid packet-size constraints. The output file therefore generally stays very close to the original size; PCAPNG packet padding can create small differences.
- **Nested perturbations**: for a particular sweep and seed, the last 10% generated packets in `gan_010` are exactly the same in `gan_020`, `gan_030`, and so on.
- **The original file is never changed**. Each output also has a packet-by-packet provenance CSV and a manifest recording percentage and file-size discrepancy.

Example of the **default packet-count basis** for a 100,000-packet input:

| Output | Untouched starting packets | Replaced final packets | Total packets |
|---|---:|---:|---:|
| `gan_000.pcapng` | 100,000 | 0 | 100,000 |
| `gan_010.pcapng` | 90,000 | 10,000 | 100,000 |
| `gan_020.pcapng` | 80,000 | 20,000 | 100,000 |
| `gan_030.pcapng` | 70,000 | 30,000 | 100,000 |
| `gan_100.pcapng` | 0 | 100,000 | 100,000 |

If the packet count is not divisible by 10, the replacement count is rounded to the closest whole packet, and the exact fraction is recorded in `manifest.csv`. `--basis packet-bytes` selects a suffix by cumulative **original packet byte counts** instead of packet count, but replacement is still one generated packet per selected source packet.

## Installation

Requires Python 3.10 or newer.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

On Windows PowerShell, activate with `.venv\\Scripts\\Activate.ps1`. Use PyTorch appropriate to your system (CPU first, then CUDA if available).

## Train on separate data

```bash
python traffic_gan.py extract --input captures/training.pcapng --features data/training.csv
python traffic_gan.py train --features data/training.csv --model models/ctgan.pkl --epochs 100 --device cpu --seed 42
```

Train on a **different** capture from the one used for evaluation to avoid leakage.

## Create perturbations

```bash
python traffic_gan.py sweep \
  --input captures/evaluation.pcapng \
  --model models/ctgan.pkl \
  --output results/seed42 \
  --percentages 0,10,20,30,40,50,60,70,80,90,100 \
  --basis packets --seed 42
```

For shorter syntax the percentages and `--basis packets` are already the default.

Each percentage produces:

- `gan_010.pcapng` (or `.pcap`) — the altered capture with the **same count of packets**.
- `gan_010.packet_labels.csv` — source/origin classification and per-packet source/output lengths.
- `gan_010.flow_labels.csv` — original-flow IDs and fraction of that flow's packets replaced.
- `gan_010.json` — packet counts, byte totals, source/output SHA256, settings, and `%` file-size difference.
- `manifest.csv` — summary for all percentages.

The output CSV tracks *actual* fractions, and the program confirms that the number of packet records is unchanged. PCAPNG files may be a little larger or smaller because blocks are padded to four bytes.

### Why size balancing is used

The GAN samples a flow-level mean IP length, protocol, port, TTL and other summary features. Each packet's proposed new length is based on its original length, the sampled flow mean and a small seeded random variation. **Within each incremental replacement band**, generated lengths are adjusted up/down as a group to keep its total bytes close to the corresponding source packets, with packet-size bounds for valid IPv4/TCP/UDP reconstruction. This allows different per-packet sizes but **does constrain the segment's overall mean packet size**; account for that when interpreting realism metrics. The suffix bands are determined once per sweep, so their contents remain stable across increasing percentages.

For unusual jumbo packets the maximum generated IPv4 datagram size is at least the input datagram size. For otherwise ordinary traffic, `--max-ip-length` defaults to `1500` (change it only where supported by the source capture).

## Important limitations of this research baseline

This is **CTGAN-conditioned template-based packet generation**, not a true packet-sequence GAN. The generated content is reconstructed from the original packet's Ethernet/IP/TCP/UDP header layout, with GAN-sampled size/TTL/port features and **pseudorandom opaque payload bytes**. IP/TCP/UDP checksums and IP/UDP lengths are corrected. CTGAN is **not** trained to generate payload byte sequences. TCP sequence/ACK numbers, application protocol syntax, encryption, and inter-packet dependencies **may be invalid**. In flows crossing the replacement boundary, the final packets can be inconsistent with earlier originals.

The original **capture timestamps are unchanged**. Timing and burstiness metrics therefore cannot test generative temporal realism in this version. Original endpoints, most transport fields and L2 headers are reused. Do not present `gan_100` as independently generated, fully synthetic network conversations; it means **every packet position contains a modified packet**.

This makes it a useful deliberately simple perturbation baseline, but you must separately evaluate the contribution of template artifacts, invalid application payloads, and the size-normalization procedure. A genuine packet-sequence generator is a later development.

### Supported inputs

- Nonfragmented, fully captured IPv4 TCP and UDP packets on Ethernet (with VLAN), Linux cooked capture v1/v2, or raw IPv4. In a 10% sweep only packets in the final 10% must be supported; at 100%, every packet must be supported.
- Standard classic PCAP and PCAPNG with Enhanced Packet Blocks or legacy Packet Blocks. PCAPNG Simple Packet Blocks are not currently supported.
- Embedded packet hash options are rejected (they would become stale). Captured FCS and truncated packets require preprocessing. Packet rewriter retains any capture metadata outside modified packet records.
- This prototype currently buffers the entire capture and decodes all packets in RAM. For multi-GB datasets use smaller reference captures or implement streaming.
- Load **only trusted model checkpoint pickle files** generated locally.

The `flow-sweep` command remains an **alternative legacy** mode that replaces whole flows in random order and does not preserve the original packet count. `exact-sweep` retains the previous strict version where every packet and output file retains precisely the original size.

## Test and inspect

```bash
pip install pytest
python -m pytest -q tests
```

Check one capture with `capinfos results/seed42/gan_010.pcapng` and `tshark -r results/seed42/gan_010.pcapng -q` or Wireshark, and inspect `manifest.csv` before passing the data into CBR-Tests. The included tests use fake GAN samples; they do **not** demonstrate end-to-end training with your actual network datasets or application-layer realism.

## Literature background

- Xu et al., *Modeling Tabular Data using Conditional GAN*, NeurIPS 2019.
- Ring et al., *Flow-based network traffic generation using Generative Adversarial Networks*, Computers & Security 82 (2019), 156–172, DOI: 10.1016/j.cose.2018.12.012.

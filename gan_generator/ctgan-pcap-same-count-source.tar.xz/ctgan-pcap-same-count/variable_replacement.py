"""Size-balanced trailing packet replacement for PCAP and PCAPNG.

Packet COUNT stays exact. Every selected packet is modified, with CTGAN-conditioned
variable lengths; each incremental sweep band is adjusted to approximate the
source band's total bytes. Timestamps, interface metadata and original prefix
are retained. This is a *template-based* generator, not valid TCP conversations.
"""
from __future__ import annotations

import random
import struct
from typing import Mapping

from tail_replacement import (CaptureError, PacketSlot, checksum, ipv4_offset,
                              locate_packet_slots, _bounded, _read_u32,
                              _validate_block, _reject_packet_hash_options)


def constraints(original: bytes, linktype: int, max_ip_length: int = 1500) -> tuple[int, int, int]:
    """Return minimum/max captured packet sizes and original IPv4 datagram size.

    Fail on truncated/fragmented/unsupported packets rather than mislabeling them.
    """
    base = ipv4_offset(original, linktype)
    if len(original) < base + 20 or original[base] >> 4 != 4:
        raise CaptureError('Not IPv4')
    ihl = (original[base] & 15) * 4
    iplen = struct.unpack_from('!H', original, base + 2)[0]
    if ihl < 20 or iplen < ihl or base + iplen > len(original):
        raise CaptureError('Truncated or malformed IPv4')
    frag = struct.unpack_from('!H', original, base + 6)[0]
    if frag & 0x3fff:
        raise CaptureError('IPv4 fragments not supported')
    l4 = base + ihl
    proto = original[base + 9]
    if proto == 6:
        if l4 + 20 > base + iplen:
            raise CaptureError('Truncated TCP header')
        thl = (original[l4 + 12] >> 4) * 4
        if thl < 20 or l4 + thl > base + iplen:
            raise CaptureError('Invalid TCP header')
    elif proto == 17:
        thl = 8
        if l4 + thl > base + iplen or struct.unpack_from('!H', original, l4 + 4)[0] != iplen - ihl:
            raise CaptureError('Invalid UDP length')
    else:
        raise CaptureError(f'Unsupported IPv4 protocol {proto}')
    min_size = max(base + ihl + thl, 60 if linktype == 1 else 0)
    max_size = base + min(65535, max(max_ip_length, iplen, ihl + thl))
    return min_size, max_size, iplen


def propose_length(original: bytes, linktype: int, feature: Mapping, original_mean_ip_length: float,
                   seed: int, max_ip_length: int = 1500) -> tuple[int, int, int]:
    """CTGAN flow-mean-size-conditioned packet length, retaining original variety."""
    lo, hi, ip_len = constraints(original, linktype, max_ip_length)
    desired_mean = _bounded(feature.get('mean_ip_length'), 28, 65535, round(original_mean_ip_length))
    ratio = desired_mean / max(1, original_mean_ip_length)
    rng = random.Random(seed)
    # Small per-packet variation (not claimed as learned temporal behaviour).
    jitter = rng.uniform(0.90, 1.10)
    base = ipv4_offset(original, linktype)
    suggested = base + round(ip_len * ratio * jitter)
    return max(lo, min(hi, suggested)), lo, hi


def balance_lengths(proposals: list[tuple[int, int, int]], target_sum: int) -> list[int]:
    """Scale packet payload lengths to hit the source byte budget when feasible.

    Keeps model-conditioned relative differences rather than requiring every
    generated packet to match its original length.
    """
    if not proposals:
        return []
    lo_sum = sum(lo for _, lo, _ in proposals)
    hi_sum = sum(hi for _, _, hi in proposals)
    target_sum = min(hi_sum, max(lo_sum, target_sum))
    if target_sum == lo_sum:
        return [lo for _, lo, _ in proposals]
    # Use a common additive offset to preserve size contrasts where unclipped.
    low = -max(hi for _, _, hi in proposals)
    high = max(hi for _, _, hi in proposals)
    for _ in range(48):
        mid = (low + high) / 2
        total = sum(max(lo, min(hi, round(pref + mid))) for pref, lo, hi in proposals)
        if total < target_sum:
            low = mid
        else:
            high = mid
    result = [max(lo, min(hi, round(pref + high))) for pref, lo, hi in proposals]
    delta = target_sum - sum(result)
    # Bounded, deterministic 1-byte correction for rounding (usually < packet count).
    if delta:
        direction = 1 if delta > 0 else -1
        candidates = [i for i, (_, lo, hi) in enumerate(proposals)
                      if (result[i] < hi if direction > 0 else result[i] > lo)]
        while delta and candidates:
            nxt = []
            for i in candidates:
                if not delta:
                    break
                result[i] += direction
                delta -= direction
                _, lo, hi = proposals[i]
                if lo < result[i] < hi:
                    nxt.append(i)
            candidates = nxt
    if sum(result) != target_sum:
        raise AssertionError('Could not reach feasible packet byte budget')
    return result


def synthesize_variable_length(original: bytes, linktype: int, feature: Mapping, seed: int,
                               target_length: int, original_service: int | None = None) -> bytes:
    """Reconstruct one IPv4 TCP/UDP packet at target length, with fresh payload.

    Headers still use an original template. TCP sequence fields / application
    data are not valid conversations. This is an offline experimental baseline.
    """
    rng = random.Random(seed)
    base = ipv4_offset(original, linktype)
    lo, hi, _ = constraints(original, linktype, max_ip_length=65535)
    if not lo <= target_length <= hi:
        raise CaptureError(f'Target length {target_length} outside safe limits [{lo},{hi}]')
    original_total = struct.unpack_from('!H', original, base + 2)[0]
    ihl = (original[base] & 15) * 4
    l4 = base + ihl
    proto = original[base + 9]
    l4_hlen = (original[l4 + 12] >> 4) * 4 if proto == 6 else 8
    # Packet container length includes link-layer; no captured FCS is supported.
    new_iplen = target_length - base
    if new_iplen < ihl + l4_hlen:
        raise CaptureError('Target cannot accommodate IP/transport headers')
    packet = bytearray(original[:l4 + l4_hlen])
    packet.extend(rng.randbytes(new_iplen - ihl - l4_hlen))
    struct.pack_into('!H', packet, base + 2, new_iplen)
    old_id = struct.unpack_from('!H', packet, base + 4)[0]
    struct.pack_into('!H', packet, base + 4, (old_id + 1 + rng.randrange(65535)) & 0xffff)
    packet[base + 8] = _bounded(feature.get('mean_ttl'), 1, 255, 64)
    # Generated service-port feature is applied consistently to the original
    # flow direction, though it can break conversations across the boundary.
    try:
        service = int(str(feature.get('service_port', 'other')))
    except (ValueError, TypeError):
        service = None
    if service is not None and 1 <= service <= 65535 and original_service is not None:
        sport, dport = struct.unpack_from('!HH', packet, l4)
        if dport == original_service:
            struct.pack_into('!H', packet, l4 + 2, service)
        elif sport == original_service:
            struct.pack_into('!H', packet, l4, service)
    if proto == 17:
        struct.pack_into('!H', packet, l4 + 4, new_iplen - ihl)
    struct.pack_into('!H', packet, base + 10, 0)
    struct.pack_into('!H', packet, base + 10, checksum(packet[base:base+ihl]))
    off = l4 + (16 if proto == 6 else 6)
    struct.pack_into('!H', packet, off, 0)
    segment = bytes(packet[l4:])
    pseudo = packet[base+12:base+20] + struct.pack('!BBH', 0, proto, len(segment))
    val = checksum(pseudo + segment)
    struct.pack_into('!H', packet, off, val or (0xffff if proto == 17 else 0))
    if original_total != new_iplen and len(packet) != target_length:
        raise AssertionError('Incorrect generated packet size')
    if len(packet) != target_length or bytes(packet) == original:
        raise AssertionError('Packet not changed or length mismatch')
    return bytes(packet)


def rewrite_variable_capture(original: bytes, slots: list[PacketSlot], generated: Mapping[int, bytes]) -> bytes:
    """Rebuild packet record lengths and PCAPNG block lengths while retaining metadata.

    Nonselected packet blocks/records are byte-identical; all section/interface
    metadata and capture timestamps are preserved. No new interfaces created.
    """
    if not generated:
        return original
    magic = {b'\xd4\xc3\xb2\xa1': '<', b'\xa1\xb2\xc3\xd4': '>',
             b'\x4d\x3c\xb2\xa1': '<', b'\xa1\xb2\x3c\x4d': '>'}
    if original[:4] in magic:
        endian = magic[original[:4]]
        out = bytearray(original[:24])
        pos = 24
        for s in slots:
            if s.offset != pos + 16:
                raise CaptureError('PCAP slot offset mismatch')
            header = bytearray(original[pos:s.offset])
            if s.index in generated:
                pack = generated[s.index]
                struct.pack_into(endian + 'II', header, 8, len(pack), len(pack))
            else:
                pack = original[s.offset:s.offset+s.length]
            out.extend(header)
            out.extend(pack)
            pos = s.offset+s.length
        if pos != len(original):
            raise CaptureError('Trailing PCAP data')
        result = bytes(out)
    else:
        pos, cursor, endian = 0, 0, None
        out = bytearray()
        while pos < len(original):
            if original[pos:pos+4] == b'\x0a\x0d\x0d\x0a':
                bom = original[pos+8:pos+12]
                endian = '<' if bom == b'\x4d\x3c\x2b\x1a' else '>' if bom == b'\x1a\x2b\x3c\x4d' else None
            if endian is None:
                raise CaptureError('Invalid PCAPNG section')
            typ = _read_u32(original, pos, endian)
            length = _read_u32(original, pos+4, endian)
            _validate_block(original, pos, length, endian)
            block = original[pos:pos+length]
            if typ in (2, 6):
                if cursor >= len(slots):
                    raise CaptureError('Slot/block count mismatch')
                slot = slots[cursor]
                cursor += 1
                if slot.index in generated:
                    pack = generated[slot.index]
                    old_padlen = (slot.length + 3) & ~3
                    data_start = slot.offset - pos
                    opts = block[data_start+old_padlen:-4]
                    head = bytearray(block[:data_start])
                    struct.pack_into(endian + 'II', head, 20, len(pack), len(pack))
                    padded = pack + b'\x00' * (-len(pack) % 4)
                    new_len = len(head) + len(padded) + len(opts) + 4
                    struct.pack_into(endian + 'I', head, 4, new_len)
                    block = bytes(head) + padded + opts + struct.pack(endian + 'I', new_len)
            out.extend(block)
            pos += length
        if cursor != len(slots):
            raise CaptureError('Not all slots written')
        result = bytes(out)
    out_slots = locate_packet_slots(result)
    if len(out_slots) != len(slots):
        raise AssertionError('Packet count changed')
    for before, after in zip(slots, out_slots):
        if before.index not in generated:
            if original[before.offset:before.offset+before.length] != result[after.offset:after.offset+after.length]:
                raise AssertionError('Unselected packet modified')
        else:
            if result[after.offset:after.offset+after.length] != generated[before.index]:
                raise AssertionError('Generated packet differs from supplied bytes')
    return result


def plan_generated_packets(original: bytes, slots: list[PacketSlot], starts: Mapping[int, int],
                           features: Mapping[int, Mapping], services: Mapping[int, int],
                           original_mean_ip_lengths: Mapping[int, float], seed: int,
                           max_ip_length: int = 1500) -> dict[int, bytes]:
    """Once per sweep: budget-balance each newly replaced band and synthesize."""
    bounds = sorted(set(starts.values()) | {len(slots)}, reverse=True)
    out: dict[int, bytes] = {}
    for right, left in zip(bounds[:-1], bounds[1:]):
        proposals = []
        for idx in range(left, right):
            slot = slots[idx]
            raw = original[slot.offset:slot.offset+slot.length]
            mean = original_mean_ip_lengths[idx]
            proposals.append(propose_length(raw, slot.linktype, features[idx], mean,
                                            seed * 1000003 + idx, max_ip_length))
        targets = balance_lengths(proposals, sum(slots[idx].length for idx in range(left, right)))
        for idx, desired in zip(range(left, right), targets):
            slot = slots[idx]
            raw = original[slot.offset:slot.offset+slot.length]
            out[idx] = synthesize_variable_length(raw, slot.linktype, features[idx],
                                                  seed * 1000003 + idx, desired, services.get(idx))
    return out

"""Count-preserving, size-balanced PCAP / PCAPNG variable-packet sweeps."""
from __future__ import annotations
import json
import pickle
import struct
import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest
from tail_replacement import checksum, locate_packet_slots
from variable_replacement import (balance_lengths, synthesize_variable_length,
                                  propose_length, rewrite_variable_capture,
                                  plan_generated_packets)
from test_tail_replacement import (packet, pcap, pcapng, FEATURES)


def test_balancer_keeps_aggregate_but_varies_individual_lengths():
    values = [(80, 60, 150), (95, 60, 150), (120, 60, 150), (70, 60, 150)]
    result = balance_lengths(values, 360)
    assert sum(result) == 360
    assert len(set(result)) > 1
    assert result != [90] * 4
    assert balance_lengths([(60, 60, 100)] * 10, 650) == [65] * 10


@pytest.mark.parametrize('format_builder', [pcap, pcapng])
def test_variable_packets_preserve_count_checksum_and_timestamps(format_builder):
    cap = format_builder([packet(i, 6 if i % 2 else 17) for i in range(100)])
    slots = locate_packet_slots(cap)
    starts = {0: 100, 10: 90, 20: 80, 100: 0}
    rows = {i: ({**FEATURES, 'protocol': 'UDP' if i % 2 == 0 else 'TCP'})
            for i in range(100)}
    services = {i: 53 if i % 2 == 0 else 443 for i in range(100)}
    means = {i: slots[i].length - 14 for i in range(100)}
    generated = plan_generated_packets(cap, slots, starts, rows, services, means, 42)
    assert len(generated) == 100
    ten = rewrite_variable_capture(cap, slots, {i: generated[i] for i in range(90, 100)})
    twenty = rewrite_variable_capture(cap, slots, {i: generated[i] for i in range(80, 100)})
    full = rewrite_variable_capture(cap, slots, generated)
    output_slots = locate_packet_slots(twenty)
    assert len(locate_packet_slots(ten)) == len(output_slots) == len(locate_packet_slots(full)) == 100
    assert abs(len(twenty) - len(cap)) <= 100  # pcapng per-packet pad variation only
    assert len({s.length for s in output_slots[80:]}) > 1
    assert all(cap[a.offset:a.offset+a.length] == twenty[b.offset:b.offset+b.length]
               for a, b in zip(slots[:80], output_slots[:80]))
    ten_slots = locate_packet_slots(ten)
    for i in range(90, 100):
        a, b = ten_slots[i], output_slots[i]
        assert ten[a.offset:a.offset+a.length] == twenty[b.offset:b.offset+b.length]
    for i in range(80, 100):
        new = twenty[output_slots[i].offset:output_slots[i].offset+output_slots[i].length]
        ip = new[14:]
        assert checksum(ip[:20]) == 0
        protocol = ip[9]
        seg = ip[20:]
        assert checksum(ip[12:20] + struct.pack('!BBH', 0, protocol, len(seg)) + seg) == 0
        assert struct.unpack_from('!H', ip, 2)[0] == len(ip)
        if protocol == 17:
            assert struct.unpack_from('!H', seg, 4)[0] == len(seg)
    # The capture header, timestamps and unchanged prefix are exactly intact.
    assert twenty[:slots[80].offset - (16 if format_builder is pcap else 28)] == cap[:slots[80].offset - (16 if format_builder is pcap else 28)]


class _FakeGAN:
    def sample(self, n, condition_column=None, condition_value=None):
        import pandas as pd
        return pd.DataFrame([{**FEATURES, 'protocol': condition_value, 'mean_ip_length': 180}
                             for _ in range(n)])


@pytest.mark.parametrize('format_builder, extension', [(pcap, 'pcap'), (pcapng, 'pcapng')])
def test_end_to_end_same_packet_count_near_size(tmp_path, monkeypatch, format_builder, extension):
    import traffic_gan
    cap = format_builder([packet(i) for i in range(100)])
    source = tmp_path / f'input.{extension}'
    source.write_bytes(cap)
    model = tmp_path / 'model.pkl'
    with model.open('wb') as fh:
        pickle.dump({'ctgan': _FakeGAN()}, fh)
    flow = traffic_gan.Flow(0, 'TCP', ('10.0.0.1', 50000), ('10.0.0.2', 443))
    flow.packet_indices = list(range(100))
    flow.times = [float(i) for i in range(100)]
    flow.lengths = [len(packet(i)) - 14 for i in range(100)]
    monkeypatch.setattr(traffic_gan, 'read_capture', lambda *a, **kw:
                        ([object()] * 100, [flow], [0] * 100))
    out = tmp_path / 'out'
    args = SimpleNamespace(input=source, model=model, output=out,
                           percentages=[0, 10, 20, 100], seed=42,
                           idle_timeout=60.0, max_packets=None, basis='packets',
                           max_ip_length=1500)
    traffic_gan.sweep(args)
    originals = locate_packet_slots(cap)
    for pct in (0, 10, 20, 100):
        capture = (out / f'gan_{pct:03d}.{extension}').read_bytes()
        slots = locate_packet_slots(capture)
        manifest = json.loads((out / f'gan_{pct:03d}.json').read_text())
        assert len(slots) == 100
        assert manifest['total_packets'] == 100
        assert manifest['synthetic_packets'] == pct
        assert abs(manifest['file_size_error_pct']) < 1.0
        assert sum(s.length for s in slots) == sum(s.length for s in originals)
        if pct == 0:
            assert capture == cap
        else:
            assert capture != cap
    ten = (out / f'gan_010.{extension}').read_bytes()
    twenty = (out / f'gan_020.{extension}').read_bytes()
    s10, s20 = locate_packet_slots(ten), locate_packet_slots(twenty)
    assert ten[s10[99].offset:s10[99].offset+s10[99].length] == twenty[s20[99].offset:s20[99].offset+s20[99].length]

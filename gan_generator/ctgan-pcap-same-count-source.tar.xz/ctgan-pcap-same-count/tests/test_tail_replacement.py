"""Tests with tiny synthetic captures; no Scapy or GAN training dependencies."""
from __future__ import annotations
import struct
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
from tail_replacement import (CaptureError, checksum, locate_packet_slots, suffix_start,
                              synthesize_fixed_length, patched_capture, verify_exact_size)


def packet(index: int, proto: int = 6) -> bytes:
    payload = f'original payload {index:03d}'.encode()
    src = bytes([10, 0, 0, 1]); dst = bytes([10, 0, 0, 2])
    if proto == 6:
        segment = bytearray(struct.pack('!HHIIHHHH', 50000, 443, 100 + index, 200, (5<<12)|0x18, 8192, 0, 0) + payload)
        checksum_offset = 16
    else:
        segment = bytearray(struct.pack('!HHHH', 50000, 53, 8+len(payload), 0) + payload)
        checksum_offset = 6
    pseudo = src+dst+struct.pack('!BBH', 0, proto, len(segment))
    struct.pack_into('!H', segment, checksum_offset, checksum(pseudo+segment))
    iph = bytearray(struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20+len(segment), index, 0, 64, proto, 0, src, dst))
    struct.pack_into('!H', iph, 10, checksum(iph))
    eth = b'\x00'*6 + b'\x11'*6 + struct.pack('!H', 0x0800)
    return eth+iph+segment


def pcap(packets: list[bytes]) -> bytes:
    raw = bytearray(struct.pack('<IHHIIII', 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))
    for i, p in enumerate(packets):
        raw.extend(struct.pack('<IIII', 100000+i, 456, len(p), len(p)))
        raw.extend(p)
    return bytes(raw)


def block(typ: int, body: bytes) -> bytes:
    body += b'\x00' * (-len(body) % 4)
    size = len(body) + 12
    return struct.pack('<II', typ, size) + body + struct.pack('<I', size)


def pcapng(packets: list[bytes]) -> bytes:
    shb = block(0x0a0d0d0a, struct.pack('<IHHq', 0x1a2b3c4d, 1, 0, -1))
    idb = block(1, struct.pack('<HHI', 1, 0, 65535))
    rows = []
    for i, p in enumerate(packets):
        rows.append(block(6, struct.pack('<IIIII', 0, 0, 10000+i, len(p), len(p)) + p))
    return shb + idb + b''.join(rows)


FEATURES = {'protocol': 'TCP', 'mean_ttl': 93, 'service_port': '8443',
            'mean_ip_length': 200, 'packet_count_log': 3.0, 'duration_ms_log': 5,
            'forward_fraction': .5}


@pytest.mark.parametrize('format_builder', [pcap, pcapng])
def test_suffix_exact_file_length_and_unchanged_prefix(format_builder):
    input_capture = format_builder([packet(i) for i in range(10)])
    slots = locate_packet_slots(input_capture)
    assert len(slots) == 10
    assert suffix_start(slots, 10) == 9
    assert suffix_start(slots, 20) == 8
    assert suffix_start(slots, 100) == 0
    assert suffix_start(slots, 0) == 10
    assert suffix_start(slots[:3], 10) == 2
    feats = {i: FEATURES for i in range(10)}
    ports = {i: 443 for i in range(10)}
    ten, count10 = patched_capture(input_capture, slots, 9, feats, ports, seed=42)
    twenty, count20 = patched_capture(input_capture, slots, 8, feats, ports, seed=42)
    assert count10 == 1 and count20 == 2
    verify_exact_size(input_capture, ten, slots, 9)
    verify_exact_size(input_capture, twenty, slots, 8)
    assert ten[:slots[9].offset] == input_capture[:slots[9].offset]
    assert len(input_capture) == len(ten) == len(twenty)
    last = slots[-1]
    assert ten[last.offset:last.offset+last.length] == twenty[last.offset:last.offset+last.length]
    # Both original & synthetic source remain valid network-layer packets.
    for s in slots[8:]:
        generated = twenty[s.offset:s.offset+s.length]
        ip = generated[14:]
        assert checksum(ip[:20]) == 0
        assert ip[8] == 93
        assert struct.unpack_from('!H', generated, 14+20+2)[0] == 8443
        transport = ip[20:]
        assert checksum(ip[12:20]+struct.pack('!BBH', 0, 6, len(transport))+transport) == 0


def test_udp_checksum_and_fixed_size():
    original = packet(3, proto=17)
    generated = synthesize_fixed_length(original, 1, {'protocol': 'UDP', 'mean_ttl': 72,
                                                        'service_port': '123'}, 5, 53)
    assert generated != original and len(generated) == len(original)
    ip = generated[14:]
    assert checksum(ip[:20]) == 0
    segment = ip[20:]
    assert checksum(ip[12:20]+struct.pack('!BBH', 0, 17, len(segment))+segment) == 0


def test_byte_fraction_uses_suffix_in_packet_bytes():
    slots = [type('S', (), {'length': x})() for x in [10, 10, 10, 100]]
    assert suffix_start(slots, 25, basis='packets') == 3
    assert suffix_start(slots, 30, basis='packet-bytes') == 3
    assert suffix_start(slots, 75, basis='packet-bytes') == 3


def test_unsupported_packet_rejected():
    data = pcap([packet(1), b'\x00'*12 + b'\x86\xdd' + b'\x60'+b'\x00'*39])
    slots = locate_packet_slots(data)
    with pytest.raises(CaptureError):
        patched_capture(data, slots, 1, {1: FEATURES}, {1: 443}, 42)


def test_pcapng_corruption_rejected():
    data = bytearray(pcapng([packet(1)]))
    data[-4:] = b'\x00\x00\x00\x00'
    with pytest.raises(CaptureError):
        locate_packet_slots(bytes(data))

class _FakeCTGAN:
    def sample(self, n, condition_column=None, condition_value=None):
        import pandas as pd
        return pd.DataFrame([{**FEATURES, 'protocol': condition_value} for _ in range(n)])


def test_complete_sweep_manifest_and_byte_identical_size(tmp_path, monkeypatch):
    import json
    import pickle
    from types import SimpleNamespace
    import traffic_gan

    input_path = tmp_path / 'input.pcapng'
    capture = pcapng([packet(i) for i in range(10)])
    input_path.write_bytes(capture)
    model_path = tmp_path / 'model.pkl'
    with model_path.open('wb') as fh:
        pickle.dump({'ctgan': _FakeCTGAN()}, fh)
    flow = traffic_gan.Flow(0, 'TCP', ('10.0.0.1', 50000), ('10.0.0.2', 443))
    flow.packet_indices = list(range(10))
    flow.times = [float(i) for i in range(10)]
    monkeypatch.setattr(traffic_gan, 'read_capture', lambda *a, **k:
                        ([object()] * 10, [flow], [0] * 10))
    args = SimpleNamespace(input=input_path, model=model_path,
                           output=tmp_path / 'outputs', percentages=[0, 10, 20, 100],
                           seed=42, idle_timeout=60.0, max_packets=None,
                           basis='packets')
    traffic_gan.exact_sweep(args)
    for pct, synthetic in [(0, 0), (10, 1), (20, 2), (100, 10)]:
        result = (args.output / f'gan_{pct:03d}.pcapng').read_bytes()
        m = json.loads((args.output / f'gan_{pct:03d}.json').read_text())
        assert len(result) == len(capture)
        assert m['synthetic_packets'] == synthetic
        assert m['total_packets'] == 10
        assert m['file_size_equal'] is True
        assert result == capture if pct == 0 else result != capture
    slots = locate_packet_slots(capture)
    ten = (args.output / 'gan_010.pcapng').read_bytes()
    twenty = (args.output / 'gan_020.pcapng').read_bytes()
    s = slots[-1]
    assert ten[s.offset:s.offset+s.length] == twenty[s.offset:s.offset+s.length]
    assert len((args.output / 'manifest.csv').read_text().splitlines()) == 5

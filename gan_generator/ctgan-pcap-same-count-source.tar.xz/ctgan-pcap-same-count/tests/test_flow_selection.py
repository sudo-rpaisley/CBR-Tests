import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from flow_selection import select_nested


def test_nested_replacements_and_full_coverage():
    sizes = {i: (i % 7) + 1 for i in range(100)}
    out = select_nested(sizes, sum(sizes.values()), range(0, 101, 10), seed=42)
    assert out[0] == frozenset()
    assert out[100] == frozenset(sizes)
    for a, b in zip(range(0, 100, 10), range(10, 101, 10)):
        assert out[a] <= out[b]
    assert out == select_nested(sizes, sum(sizes.values()), range(0, 101, 10), seed=42)


def test_protected_population_prevents_100_percent():
    sizes = {0: 2, 1: 3}
    out = select_nested(sizes, 6, [0, 10, 100])
    assert sum(sizes[i] for i in out[100]) == 5


def test_exact_ten_percent_steps_for_one_packet_flows():
    sizes = {i: 1 for i in range(100)}
    out = select_nested(sizes, 100, range(0, 101, 10), seed=17)
    for percent, selected in out.items():
        assert len(selected) == percent

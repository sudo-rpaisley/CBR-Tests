# Changes — fixed-size suffix replacement

- Default `sweep` now modifies the **last N% of ordered packet slots** instead of randomly selected complete flows.
- Output remains the exact same number of bytes on disk as the input, including for PCAPNG. Packet count and recorded timestamps are unchanged.
- The initial portion of each output is byte-identical to the input. Generated suffixes are nested and stable across percentages for the same seed.
- `--basis packets` is default; `--basis packet-bytes` is optional for approximate trailing captured-byte fractions.
- Packet bytes are modified in their existing PCAP/PCAPNG containers, with regenerated IPv4 TCP/UDP checksums. Unsupported packets in the selected suffix cause a clear error rather than a false percentage claim.
- Manifests report observed packet/byte fractions, unchanged-file-size validation, per-packet and per-flow provenance.
- Previous whole-flow, potentially size-changing algorithm remains available explicitly as `flow-sweep`.
- Tests exercise both PCAP and PCAPNG, packet checksums, suffix selection and an end-to-end sweep using a mock GAN.

**Known limitation:** These are synthetic **packet-template edits** conditioned on a CTGAN trained on flow-level features, not learned application messages or packet sequences. Retained byte lengths and timestamps are controlled properties, not evidence of synthetic realism.

## Same-count, near-size sweep revision (2026-10-21)

- The default `sweep` command now replaces the **last X% of packet positions**, keeping the **total packet count identical**.
- Generated packet sizes can vary; group byte-budget balancing makes the complete PCAP/PCAPNG sizes as close as possible, subject to transport header and packet-size constraints.
- Packet lengths, IPv4 and UDP lengths, checksums and capture record/block lengths are rewritten consistently for classic PCAP and PCAPNG.
- Source packet timestamps, original prefix and capture metadata remain unchanged. Nested suffix generations share packet bytes.
- Renamed the previous strict replacement to `exact-sweep` for optional comparison.
- Added tests for both capture formats, packet counts, checksum correctness, generated length variation, repeatability and near-size matching.

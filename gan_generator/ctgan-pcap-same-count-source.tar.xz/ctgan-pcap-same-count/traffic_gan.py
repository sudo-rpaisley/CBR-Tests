#!/usr/bin/env python3
"""Research prototype: CTGAN flow features -> offline PCAP perturbation sweep.

NOT a full packet-sequence model. No packets are sent onto a network.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import pickle
import random
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from flow_selection import select_nested
from tail_replacement import (locate_packet_slots, suffix_start, patched_capture,
                              verify_exact_size, digest, CaptureError)
from variable_replacement import plan_generated_packets, rewrite_variable_capture


COLUMNS = ["protocol", "service_port", "packet_count_log", "duration_ms_log",
           "mean_ip_length", "forward_fraction", "mean_ttl"]
DISCRETE = ["protocol", "service_port"]
COMMON_SERVICES = {20, 21, 22, 25, 53, 67, 68, 80, 110, 123, 143, 161,
                   389, 443, 445, 465, 514, 587, 636, 853, 993, 995, 1433,
                   1883, 3306, 3389, 5060, 5432, 5672, 8080, 8443, 8883}


@dataclass
class Flow:
    uid: int
    protocol: str
    endpoint_a: tuple[str, int]
    endpoint_b: tuple[str, int]
    packet_indices: list[int] = field(default_factory=list)
    times: list[float] = field(default_factory=list)
    lengths: list[int] = field(default_factory=list)
    ttls: list[int] = field(default_factory=list)
    directions: list[int] = field(default_factory=list)

    @property
    def count(self):
        return len(self.packet_indices)

    @property
    def start(self):
        return min(self.times)

    @property
    def duration(self):
        return max(self.times) - self.start

    def summary(self):
        port = self.endpoint_b[1]
        return {
            "protocol": self.protocol,
            "service_port": str(port) if port in COMMON_SERVICES else "other",
            "packet_count_log": math.log1p(self.count),
            "duration_ms_log": math.log1p(max(0, self.duration) * 1000),
            "mean_ip_length": sum(self.lengths) / self.count,
            "forward_fraction": sum(self.directions) / self.count,
            "mean_ttl": sum(self.ttls) / self.count,
        }


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_capture(path, *, max_packets=None, idle_timeout=60.0):
    from scapy.all import IP, TCP, UDP, PcapReader
    packets, flows, active, flow_for_packet = [], [], {}, []
    layers = set()
    reader = PcapReader(str(path))  # auto-detects pcap versus pcapng
    try:
        for i, pkt in enumerate(reader):
            if max_packets is not None and i >= max_packets:
                print(f"NOTE: explicit pilot cap: first {max_packets} packets only")
                break
            packets.append(pkt)
            layers.add(type(pkt).__name__)
            flow_for_packet.append(None)
            if IP not in pkt or (TCP not in pkt and UDP not in pkt):
                continue  # leave non-IPv4/TCP/UDP traffic unchanged
            ip = pkt[IP]
            segment = pkt[TCP] if TCP in pkt else pkt[UDP]
            proto = "TCP" if TCP in pkt else "UDP"
            a = (str(ip.src), int(segment.sport))
            b = (str(ip.dst), int(segment.dport))
            key = (proto, tuple(sorted((a, b))))
            t = float(pkt.time)
            existing = active.get(key)
            if existing is None or t - flows[existing].times[-1] > idle_timeout:
                uid = len(flows)
                flows.append(Flow(uid, proto, a, b))
                active[key] = uid
            else:
                uid = existing
            f = flows[uid]
            f.packet_indices.append(i)
            f.times.append(t)
            f.lengths.append(int(ip.len or len(bytes(ip))))
            f.ttls.append(int(ip.ttl))
            f.directions.append(1 if a == f.endpoint_a else 0)
            flow_for_packet[-1] = uid
    finally:
        reader.close()
    if len(layers) > 1:
        raise ValueError(f"Mixed link-layer packet types {layers}: not supported by this prototype")
    if not packets or not flows:
        raise ValueError("No supported IPv4 TCP/UDP flows found")
    return packets, flows, flow_for_packet


def extract(args):
    import pandas as pd
    packets, flows, mapping = read_capture(args.input, max_packets=args.max_packets,
                                           idle_timeout=args.idle_timeout)
    df = pd.DataFrame.from_records([f.summary() for f in flows], columns=COLUMNS)
    args.features.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.features, index=False)
    desc = {"input": str(args.input), "input_sha256": sha256(args.input),
            "packets_used": len(packets), "flow_count": len(flows),
            "unsupported_packet_count": sum(m is None for m in mapping),
            "max_packets": args.max_packets, "idle_timeout": args.idle_timeout,
            "columns": COLUMNS}
    args.features.with_suffix(".metadata.json").write_text(json.dumps(desc, indent=2))
    print(json.dumps(desc, indent=2))


def train(args):
    import numpy as np
    import pandas as pd
    import torch
    from ctgan import CTGAN
    df = pd.read_csv(args.features, dtype={"protocol": str, "service_port": str})
    if not set(COLUMNS).issubset(df.columns):
        raise ValueError(f"Required columns: {COLUMNS}")
    if len(df) < 50:
        raise ValueError("Need at least 50 flows for a basic smoke-train; preferably thousands")
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    model = CTGAN(epochs=args.epochs, batch_size=args.batch_size, pac=10,
                  cuda=args.device == "cuda", verbose=True)
    model.fit(df[COLUMNS], discrete_columns=DISCRETE)
    args.model.parent.mkdir(parents=True, exist_ok=True)
    # WARNING: pickle is unsafe from untrusted sources. Only load models you trained.
    with open(args.model, "wb") as fh:
        pickle.dump({"ctgan": model, "columns": COLUMNS,
                     "training_sha256": sha256(args.features),
                     "epochs": args.epochs, "seed": args.seed}, fh)
    print(f"Saved model: {args.model}")


def bounded_number(value, low, high, default):
    try:
        v = float(value)
        return min(high, max(low, v)) if math.isfinite(v) else default
    except (ValueError, TypeError):
        return default


def render_flow(flow, first_packet, features, seed, capture_end):
    """Create one synthetic flow slot with identical packet budget.

    IPs/MAC/link-layer envelope are retained from the selected original slot;
    model produces behavioural summaries, not application payload semantics.
    """
    from scapy.all import IP, TCP, UDP, Raw
    rng = random.Random(seed)
    protocol = str(features.get("protocol", flow.protocol))
    if protocol not in {"TCP", "UDP"}:
        protocol = flow.protocol
    original_service = flow.endpoint_b[1]
    raw_port = str(features.get("service_port", "other"))
    try:
        port = int(raw_port)
        if not 1 <= port <= 65535:
            port = original_service
    except ValueError:
        port = original_service
    src_port = flow.endpoint_a[1]
    if src_port == port:
        src_port = rng.randint(49152, 65535)
    mean_len = bounded_number(features.get("mean_ip_length"), 40, 1500, 200)
    ttl = round(bounded_number(features.get("mean_ttl"), 1, 255, 64))
    fraction = bounded_number(features.get("forward_fraction"), 0, 1, 0.5)
    try:
        duration_ms = math.expm1(bounded_number(features.get("duration_ms_log"), 0, 19, 0))
    except OverflowError:
        duration_ms = 0
    desired_duration = duration_ms / 1000
    # Do not place synthetic packets past the capture's existing endpoint.
    duration = min(desired_duration, max(0, capture_end - flow.start))
    # Clamp the duration relative to the replaced flow slot to avoid huge drifts.
    duration = min(duration, max(0.001, 3 * flow.duration))
    n = flow.count  # forced equality: meaningful packet mixture percentage
    seq = [rng.getrandbits(32), rng.getrandbits(32)]
    generated = []
    for i in range(n):
        if protocol == "TCP" and n >= 3 and i < 3:
            direction = [0, 1, 0][i]
            flags = ["S", "SA", "A"][i]
        else:
            direction = 0 if rng.random() < fraction else 1
            flags = "PA" if i % 2 else "A"
            if protocol == "TCP" and n >= 7 and i == n - 2:
                flags = "FA"
            if protocol == "TCP" and n >= 7 and i == n - 1:
                flags = "A"
        if direction == 0:
            src, dst = flow.endpoint_a[0], flow.endpoint_b[0]
            sport, dport = src_port, port
        else:
            src, dst = flow.endpoint_b[0], flow.endpoint_a[0]
            sport, dport = port, src_port
        ip = IP(src=src, dst=dst, ttl=ttl, id=rng.randrange(65536))
        if protocol == "TCP":
            layer = TCP(sport=sport, dport=dport, flags=flags, seq=seq[direction],
                        ack=seq[1 - direction] if "A" in flags else 0, window=8192)
            header = 40
            payload_size = 0 if "S" in flags or "F" in flags else max(0, round(mean_len - header + rng.gauss(0, 35)))
        else:
            layer = UDP(sport=sport, dport=dport)
            header = 28
            payload_size = max(1, round(mean_len - header + rng.gauss(0, 35)))
        payload_size = min(1400, payload_size)
        payload = Raw(load=rng.randbytes(payload_size)) if payload_size else b""
        synthetic_ip = ip / layer / payload
        if protocol == "TCP":
            seq[direction] = (seq[direction] + payload_size + int("S" in flags) + int("F" in flags)) % (2 ** 32)
        # Preserves the original L2/VLAN envelope, but replaces the whole IP layer.
        if isinstance(first_packet, IP):
            pkt = synthetic_ip
        else:
            # Strip the old IP payload at its immediate parent, preserving
            # Ether, 802.1Q, Linux cooked, and other lower-layer headers.
            pkt = first_packet.copy()
            pkt[IP].underlayer.remove_payload()
            pkt = pkt / synthetic_ip
        pkt.time = flow.start + (i / (n - 1) * duration if n > 1 else 0)
        generated.append(pkt)
    return generated, protocol


def flow_sweep(args):
    import numpy as np
    import torch
    from scapy.utils import PcapNgWriter
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    with open(args.model, "rb") as f:
        payload = pickle.load(f)  # load only your own trusted model file
    model = payload["ctgan"]
    packets, flows, mapping = read_capture(args.input, max_packets=args.max_packets,
                                           idle_timeout=args.idle_timeout)
    total = len(packets)
    protected = sum(m is None for m in mapping)
    fractions = sorted(set(args.percentages))
    selected = select_nested({f.uid: f.count for f in flows}, total, fractions, args.seed)
    # Do not misreport 100% coverage if unsupported packets are retained.
    if 100 in fractions and protected:
        raise ValueError(f"Cannot build GAN-100: {protected}/{total} packets are unsupported "
                         "(non-IPv4 TCP/UDP). Filter to the target population first.")
    samples = model.sample(len(flows))
    if not set(COLUMNS).issubset(samples.columns):
        raise ValueError("Model output lacks expected feature columns")
    capture_end = max(float(p.time) for p in packets)
    original_packet_bytes = [len(bytes(p)) for p in packets]
    original_total_bytes = sum(original_packet_bytes)
    generated = {}
    for f, (_, row) in zip(flows, samples.iterrows()):
        gen, protocol = render_flow(f, packets[f.packet_indices[0]], row.to_dict(),
                                    args.seed * 1000003 + f.uid, capture_end)
        generated[f.uid] = gen
    original_flow_bytes = {f.uid: sum(original_packet_bytes[i] for i in f.packet_indices)
                           for f in flows}
    generated_flow_bytes = {uid: sum(len(bytes(p)) for p in pp)
                            for uid, pp in generated.items()}
    args.output.mkdir(parents=True, exist_ok=True)
    result = []
    input_digest = sha256(args.input)
    model_digest = sha256(args.model)
    for pct in fractions:
        chosen = selected[pct]
        replaced_indices = {idx for f in flows if f.uid in chosen for idx in f.packet_indices}
        num_synthetic = len(replaced_indices)
        actual = 100 * num_synthetic / total
        generated_byte_count = sum(generated_flow_bytes[uid] for uid in chosen)
        output_byte_count = (original_total_bytes
                             - sum(original_flow_bytes[uid] for uid in chosen)
                             + generated_byte_count)
        output = args.output / f"gan_{pct:03d}.pcapng"
        labels_path = args.output / f"gan_{pct:03d}.packet_labels.csv"
        flow_labels_path = args.output / f"gan_{pct:03d}.flow_labels.csv"
        if pct == 0 and args.input.suffix.lower() == ".pcapng" and args.max_packets is None:
            # Byte-identical zero-percent control, including PCAPNG metadata.
            shutil.copy2(args.input, output)
            provenance = [(idx, "real", mapping[idx]) for idx in range(total)]
        else:
            merged = [(float(pkt.time), i, pkt, False, mapping[i])
                      for i, pkt in enumerate(packets) if i not in replaced_indices]
            for f in flows:
                if f.uid in chosen:
                    merged.extend((float(pkt.time), f.packet_indices[0] + j * 1e-6,
                                   pkt, True, f.uid)
                                  for j, pkt in enumerate(generated[f.uid]))
            merged.sort(key=lambda rec: (rec[0], rec[1]))
            provenance = []
            writer = PcapNgWriter(str(output))
            try:
                for position, (_, _, pkt, is_synthetic, uid) in enumerate(merged):
                    writer.write(pkt)
                    provenance.append((position, "synthetic" if is_synthetic else "real", uid))
            finally:
                writer.close()
        with labels_path.open("w", newline="") as h:
            w = csv.writer(h)
            w.writerow(["output_packet_index", "origin", "source_flow_uid"])
            w.writerows(provenance)
        with flow_labels_path.open("w", newline="") as h:
            w = csv.writer(h)
            w.writerow(["source_flow_uid", "packet_count", "flow_start_time",
                        "original_protocol", "is_replaced"])
            for f in flows:
                w.writerow([f.uid, f.count, f.start, f.protocol, int(f.uid in chosen)])
        count_out = total  # each replaced flow has exactly the original number of packets
        if len(replaced_indices) + total - len(replaced_indices) != count_out:
            raise AssertionError("Output count mismatch")
        record = {"requested_pct": pct, "actual_packet_pct": round(actual, 6),
                  "real_packets": total - num_synthetic,
                  "synthetic_packets": num_synthetic, "total_packets": total,
                  "synthetic_flows": len(chosen), "total_supported_flows": len(flows),
                  "actual_flow_pct": round(100 * len(chosen) / len(flows), 6),
                  "synthetic_bytes": generated_byte_count, "total_output_bytes": output_byte_count,
                  "actual_byte_pct": round(100 * generated_byte_count / output_byte_count, 6),
                  "protected_packets": protected, "output": output.name,
                  "packet_labels": labels_path.name, "flow_labels": flow_labels_path.name,
                  "output_sha256": sha256(output), "input_sha256": input_digest,
                  "model_sha256": model_digest, "seed": args.seed,
                  "max_packets": args.max_packets, "idle_timeout": args.idle_timeout,
                  "note": "flow slot reconstruction; GAN feature-level only; payload bytes random; "
                          "original endpoint/link-layer metadata reused"}
        output.with_suffix(".json").write_text(json.dumps(record, indent=2))
        result.append(record)
        print(f"GAN-{pct:03d}: {num_synthetic}/{total} packets synthetic "
              f"({actual:.3f}%), {len(chosen)} flows -> {output}")
        if abs(actual - pct) > args.tolerance:
            print(f"  WARNING: exceeds +- {args.tolerance:.2f} percentage-point tolerance; "
                  "full-flow indivisibility prevents precise target")
    with (args.output / "manifest.csv").open("w", newline="") as h:
        writer = csv.DictWriter(h, fieldnames=list(result[0]))
        writer.writeheader()
        writer.writerows(result)
    print(f"Manifest: {args.output / 'manifest.csv'}")



def exact_sweep(args):
    """Legacy exact-file-size suffix-only replacement (same length per packet)."""
    import numpy as np
    import torch

    if args.max_packets is not None:
        raise ValueError('Exact-size sweep must use the ENTIRE input capture; '
                         'do not pass --max-packets. Make a separate pilot capture first.')
    if not args.input.is_file():
        raise FileNotFoundError(args.input)
    if args.input.suffix.lower() not in {'.pcap', '.pcapng'}:
        raise ValueError('Expected .pcap or .pcapng capture')
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    with open(args.model, 'rb') as fh:
        payload = pickle.load(fh)  # trusted, locally trained model ONLY
    model = payload['ctgan']
    original = args.input.read_bytes()
    slots = locate_packet_slots(original)
    if not slots:
        raise ValueError('Input capture is empty')
    packets, flows, mapping = read_capture(args.input, idle_timeout=args.idle_timeout)
    if len(packets) != len(slots):
        raise ValueError('Scapy packet count differs from raw capture count; cannot '
                         'safely associate GAN features with packet slots')
    fractions = sorted(set(args.percentages))
    if any(not 0 <= p <= 100 for p in fractions):
        raise ValueError('Percentages must be in range 0..100')
    starts = {p: suffix_start(slots, p, args.basis) for p in fractions}
    earliest = min(starts.values())
    if any(mapping[i] is None for i in range(earliest, len(slots))):
        first = next(i for i in range(earliest, len(slots)) if mapping[i] is None)
        raise ValueError(f'Packet {first} is not in an IPv4 TCP/UDP flow. Exact synthetic '
                         'suffix percentages require all selected packets to be supported. '
                         'Filter the evaluation capture or choose a lower percentage.')
    # Sample once and reuse it across the nested sweep, so the same packet
    # remains exactly the same when moving from 10% to 20%, etc.
    features_for_flow = {}
    for protocol in sorted({f.protocol for f in flows}):
        group = [f for f in flows if f.protocol == protocol]
        samples = model.sample(len(group), condition_column='protocol',
                               condition_value=protocol)
        if not set(COLUMNS).issubset(samples.columns) or len(samples) != len(group):
            raise ValueError('GAN output lacks feature columns or has wrong row count')
        for f, (_, row) in zip(group, samples.iterrows()):
            features_for_flow[f.uid] = row.to_dict()
    original_service = {f.uid: f.endpoint_b[1] for f in flows}
    by_slot = {i: features_for_flow[mapping[i]] for i in range(earliest, len(slots))}
    services = {i: original_service[mapping[i]] for i in range(earliest, len(slots))}
    output_dir = args.output
    output_dir.mkdir(parents=True, exist_ok=True)
    total_data_bytes = sum(s.length for s in slots)
    input_sha = digest(original)
    model_sha = sha256(args.model)
    manifest = []
    for pct in fractions:
        start = starts[pct]
        changed = len(slots) - start
        if changed:
            output_bytes, generated = patched_capture(original, slots, start,
                                                      by_slot, services, args.seed)
        else:
            output_bytes, generated = original, 0
        verify_exact_size(original, output_bytes, slots, start)
        out_file = output_dir / f'gan_{pct:03d}{args.input.suffix.lower()}'
        out_file.write_bytes(output_bytes)
        if out_file.stat().st_size != args.input.stat().st_size:
            raise AssertionError('Output size differs from input file size')
        label_file = output_dir / f'gan_{pct:03d}.packet_labels.csv'
        with label_file.open('w', newline='') as fh:
            w = csv.writer(fh)
            w.writerow(['output_packet_index', 'origin', 'source_flow_uid'])
            for i, flow_uid in enumerate(mapping):
                w.writerow([i, 'synthetic' if i >= start else 'real', flow_uid])
        flow_file = output_dir / f'gan_{pct:03d}.flow_labels.csv'
        replaced_by_flow = {f.uid: 0 for f in flows}
        for i in range(start, len(slots)):
            replaced_by_flow[mapping[i]] += 1
        with flow_file.open('w', newline='') as fh:
            w = csv.writer(fh)
            w.writerow(['source_flow_uid', 'packet_count', 'synthetic_packet_count',
                        'first_packet_index', 'flow_start_time', 'original_protocol'])
            for f in flows:
                w.writerow([f.uid, f.count, replaced_by_flow[f.uid],
                            min(f.packet_indices), f.start, f.protocol])
        touched = sum(bool(n) for n in replaced_by_flow.values())
        full = sum(n == f.count for f in flows for n in [replaced_by_flow[f.uid]])
        new_data_bytes = sum(s.length for s in slots[start:])
        record = {
            'requested_pct': pct,
            'percentage_basis': args.basis,
            'actual_packet_pct': round(100 * changed / len(slots), 6),
            'actual_packet_data_byte_pct': round(100 * new_data_bytes / total_data_bytes, 6),
            'synthetic_packets': changed,
            'real_packets': len(slots) - changed,
            'total_packets': len(slots),
            'synthetic_packet_data_bytes': new_data_bytes,
            'total_packet_data_bytes': total_data_bytes,
            'source_file_bytes': len(original),
            'output_file_bytes': len(output_bytes),
            'file_size_equal': len(original) == len(output_bytes),
            'untouched_prefix_packet_count': start,
            'flow_count': len(flows),
            'flows_touched': touched,
            'flows_fully_replaced': full,
            'flows_partially_replaced': touched - full,
            'output': out_file.name,
            'packet_labels': label_file.name,
            'flow_labels': flow_file.name,
            'input_sha256': input_sha,
            'output_sha256': digest(output_bytes),
            'model_sha256': model_sha,
            'seed': args.seed,
            'note': 'CTGAN feature-conditioned template replacement; packet lengths, '
                    'packet count, timestamps, untouched prefix and PCAP/PCAPNG structure '
                    'kept byte-for-byte; generated payload is opaque and not app-valid'
        }
        (output_dir / f'gan_{pct:03d}.json').write_text(json.dumps(record, indent=2))
        manifest.append(record)
        print(f'GAN-{pct:03d}: replaced final {changed}/{len(slots)} packets '
              f'({record["actual_packet_pct"]:.3f}%), '
              f'EXACT file size {len(output_bytes):,} bytes -> {out_file}')
    with (output_dir / 'manifest.csv').open('w', newline='') as fh:
        writer = csv.DictWriter(fh, fieldnames=list(manifest[0]))
        writer.writeheader()
        writer.writerows(manifest)
    print(f'Manifest: {output_dir / "manifest.csv"}')


def sweep(args):
    """Replace the final X% of packet positions; preserve count and near-match size.

    Every output is one-for-one in packet positions; a single set of generated
    packets is reused across nested percentages. Generated packet lengths may
    vary, and each additional 10% band is size-balanced as a group.
    """
    import numpy as np
    import torch

    if args.max_packets is not None:
        raise ValueError('Sweep uses the complete original capture. Create a smaller reference capture for a pilot.')
    if not args.input.is_file():
        raise FileNotFoundError(args.input)
    if args.input.suffix.lower() not in {'.pcap', '.pcapng'}:
        raise ValueError('Expected .pcap or .pcapng input')
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    with open(args.model, 'rb') as fh:
        payload = pickle.load(fh)  # Only locally trained, trusted checkpoints
    model = payload['ctgan']
    original = args.input.read_bytes()
    slots = locate_packet_slots(original)
    if not slots:
        raise ValueError('No packets in capture')
    packets, flows, mapping = read_capture(args.input, idle_timeout=args.idle_timeout)
    if len(packets) != len(slots):
        raise ValueError('Scapy packet count differs from raw PCAP/PCAPNG count')
    fractions = sorted(set(args.percentages))
    if not fractions or any(not 0 <= p <= 100 for p in fractions):
        raise ValueError('Need one or more percentages between 0 and 100')
    starts = {p: suffix_start(slots, p, args.basis) for p in fractions}
    earliest = min(starts.values())
    if any(mapping[i] is None for i in range(earliest, len(slots))):
        first = next(i for i in range(earliest, len(slots)) if mapping[i] is None)
        raise ValueError(f'Packet {first} is not an IPv4 TCP/UDP flow; cannot replace '
                         'every selected packet. Filter unsupported packets first.')
    sampled = {}
    for protocol in sorted({f.protocol for f in flows}):
        group = [f for f in flows if f.protocol == protocol]
        table = model.sample(len(group), condition_column='protocol', condition_value=protocol)
        if not set(COLUMNS).issubset(table.columns) or len(table) != len(group):
            raise ValueError('GAN output missing columns or sampled the wrong number of rows')
        for f, (_, row) in zip(group, table.iterrows()):
            sampled[f.uid] = row.to_dict()
    by_slot = {idx: sampled[mapping[idx]] for idx in range(earliest, len(slots))}
    services = {idx: flows[mapping[idx]].endpoint_b[1] for idx in range(earliest, len(slots))}
    flow_means = {f.uid: sum(f.lengths) / f.count for f in flows}
    means = {idx: flow_means[mapping[idx]] for idx in range(earliest, len(slots))}
    generated = plan_generated_packets(original, slots, starts, by_slot, services, means,
                                       args.seed, args.max_ip_length)
    if len(generated) != len(slots)-earliest:
        raise AssertionError('Not all selected packet slots have replacements')
    args.output.mkdir(parents=True, exist_ok=True)
    source_size = len(original)
    source_hash = digest(original)
    model_hash = sha256(args.model)
    total_source_pkt_bytes = sum(s.length for s in slots)
    manifest = []
    for pct in fractions:
        start = starts[pct]
        replacements = {i: generated[i] for i in range(start, len(slots))}
        result = rewrite_variable_capture(original, slots, replacements)
        out_slots = locate_packet_slots(result)
        if len(out_slots) != len(slots):
            raise AssertionError('Packet count changed')
        output = args.output / f'gan_{pct:03d}{args.input.suffix.lower()}'
        output.write_bytes(result)
        packet_labels = args.output / f'gan_{pct:03d}.packet_labels.csv'
        with packet_labels.open('w', newline='') as fh:
            w = csv.writer(fh)
            w.writerow(['output_packet_index', 'origin', 'source_flow_uid',
                        'original_packet_bytes', 'output_packet_bytes'])
            for old, new, flow_uid in zip(slots, out_slots, mapping):
                w.writerow([old.index, 'synthetic' if old.index >= start else 'real',
                            flow_uid, old.length, new.length])
        touched_counts = {f.uid: 0 for f in flows}
        for i in range(start, len(slots)):
            touched_counts[mapping[i]] += 1
        flow_labels = args.output / f'gan_{pct:03d}.flow_labels.csv'
        with flow_labels.open('w', newline='') as fh:
            w = csv.writer(fh)
            w.writerow(['source_flow_uid', 'packet_count', 'synthetic_packet_count',
                        'first_packet_index', 'flow_start_time', 'original_protocol'])
            for f in flows:
                w.writerow([f.uid, f.count, touched_counts[f.uid],
                            f.packet_indices[0], f.start, f.protocol])
        changed = len(slots) - start
        oldbytes = sum(s.length for s in slots[start:])
        flow_touched = sum(count > 0 for count in touched_counts.values())
        flow_complete = sum(touched_counts[f.uid] == f.count for f in flows)
        entry = {
            'requested_pct': pct,
            'percentage_basis': args.basis,
            'actual_packet_pct': round(changed * 100 / len(slots), 6),
            'actual_replaced_source_packet_byte_pct': round(oldbytes * 100 / total_source_pkt_bytes, 6),
            'synthetic_packets': changed,
            'real_packets': len(slots) - changed,
            'total_packets': len(slots),
            'source_packet_data_bytes': total_source_pkt_bytes,
            'output_packet_data_bytes': sum(s.length for s in out_slots),
            'source_file_bytes': source_size,
            'output_file_bytes': len(result),
            'file_size_error_pct': round((len(result) - source_size) * 100 / source_size, 6),
            'file_size_equal': len(result) == source_size,
            'untouched_prefix_packet_count': start,
            'flow_count': len(flows),
            'flows_touched': flow_touched,
            'flows_fully_replaced': flow_complete,
            'flows_partially_replaced': flow_touched - flow_complete,
            'output': output.name,
            'packet_labels': packet_labels.name,
            'flow_labels': flow_labels.name,
            'input_sha256': source_hash,
            'output_sha256': digest(result),
            'model_sha256': model_hash,
            'seed': args.seed,
            'note': 'Same packet count, generated variable packet sizes, byte-balanced increment bands; '
                    'original timestamps retained; reconstructed from packet headers and opaque random payloads, '
                    'not semantically valid TCP/application traffic.'
        }
        (args.output / f'gan_{pct:03d}.json').write_text(json.dumps(entry, indent=2))
        manifest.append(entry)
        print(f'GAN-{pct:03d}: replaced trailing {changed:,}/{len(slots):,} packets '
              f'({entry["actual_packet_pct"]:.3f}%), size difference '
              f'{entry["file_size_error_pct"]:+.4f}%, -> {output}')
    with (args.output / 'manifest.csv').open('w', newline='') as fh:
        writer = csv.DictWriter(fh, fieldnames=list(manifest[0]))
        writer.writeheader()
        writer.writerows(manifest)
    print(f'Manifest: {args.output / "manifest.csv"}')


def cli():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)
    a = sub.add_parser("extract", help="PCAP/PCAPNG to CTGAN flow feature CSV")
    a.add_argument("--input", type=Path, required=True)
    a.add_argument("--features", type=Path, required=True)
    a.add_argument("--idle-timeout", type=float, default=60.0)
    a.add_argument("--max-packets", type=int, default=None, help="EXPLICIT truncated pilot only")
    a.set_defaults(handler=extract)
    a = sub.add_parser("train", help="Train real CTGAN on flow CSV")
    a.add_argument("--features", type=Path, required=True)
    a.add_argument("--model", type=Path, required=True)
    a.add_argument("--epochs", type=int, default=100)
    a.add_argument("--batch-size", type=int, default=100)
    a.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    a.add_argument("--seed", type=int, default=42)
    a.set_defaults(handler=train)
    a = sub.add_parser("sweep", help="Replace the trailing percentage of packets; same packet count, approximately same file size")
    a.add_argument("--input", type=Path, required=True)
    a.add_argument("--model", type=Path, required=True)
    a.add_argument("--output", type=Path, required=True)
    a.add_argument("--percentages", type=lambda s: [int(i) for i in s.split(",")],
                   default=list(range(0, 101, 10)))
    a.add_argument("--seed", type=int, default=42)
    a.add_argument("--idle-timeout", type=float, default=60.0)
    a.add_argument("--max-packets", type=int, default=None,
                   help="Not allowed; first create a smaller capture for a pilot")
    a.add_argument("--basis", choices=["packets", "packet-bytes"], default="packets",
                   help="Select the trailing X percent of packet count (default) or source packet bytes")
    a.add_argument("--max-ip-length", type=int, default=1500,
                   help="Maximum sampled IPv4 datagram size for normal-MTU packets (default 1500)")
    a.set_defaults(handler=sweep)
    # Optional strict mode keeps the old equality constraint per packet slot.
    a = sub.add_parser("exact-sweep", help="Legacy strict mode: exact same size for every packet and file")
    a.add_argument("--input", type=Path, required=True)
    a.add_argument("--model", type=Path, required=True)
    a.add_argument("--output", type=Path, required=True)
    a.add_argument("--percentages", type=lambda s: [int(i) for i in s.split(",")],
                   default=list(range(0, 101, 10)))
    a.add_argument("--seed", type=int, default=42)
    a.add_argument("--idle-timeout", type=float, default=60.0)
    a.add_argument("--max-packets", type=int, default=None)
    a.add_argument("--basis", choices=["packets", "packet-bytes"], default="packets")
    a.set_defaults(handler=exact_sweep)
    # Retain the earlier flow-wide replacement as a separate comparison method.
    # This legacy mode DOES NOT guarantee file size or a trailing suffix.
    a = sub.add_parser("flow-sweep", help="LEGACY: replace randomly selected full flows; file size MAY CHANGE")
    a.add_argument("--input", type=Path, required=True)
    a.add_argument("--model", type=Path, required=True)
    a.add_argument("--output", type=Path, required=True)
    a.add_argument("--percentages", type=lambda s: [int(i) for i in s.split(",")],
                   default=list(range(0, 101, 10)))
    a.add_argument("--seed", type=int, default=42)
    a.add_argument("--idle-timeout", type=float, default=60.0)
    a.add_argument("--max-packets", type=int, default=None)
    a.add_argument("--tolerance", type=float, default=1.0)
    a.set_defaults(handler=flow_sweep)
    args = p.parse_args()
    args.handler(args)


if __name__ == "__main__":
    cli()
